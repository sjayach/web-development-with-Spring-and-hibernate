package csjobs.web.validator;

public class LoginValidator {

}
