package csjobs.model.dao;

import csjobs.model.Job;

public interface JobDao {
	
	Job saveJob( Job job );

}
